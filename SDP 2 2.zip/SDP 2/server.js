// Importing installed libraries that were installed via NPM
const express = require("express");
const app = express();

const mysql = require('mysql');

// const bodyparser = require("body-parser")
const bcrypt = require("bcrypt");

var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "7vvjsn78g3dtns_q1p2xzm000gn",
    database: "greenprop"
});

// Storing users info in array
const users = []

//
function registerUser(username, password) {
  // Check if the user already exists
  const userExists = users.some(user => user.username === username);

  if (userExists) {
    return { success: false, message: 'User already exists' };
  }

  // Add the new user to the array
  users.push({ username, password });
  return { success: true, message: 'User registered successfully' };
}

function authenticateUser(username, password) {
  // Find the user in the array
  const user = users.find(user => user.username === username);

  if (!user) {
    return { success: false, message: 'User not found' };
    }

  // Check if the password is correct
  if (user.password !== password) {
    return { success: false, message: 'Incorrect password' };
  }
return { success: true, message: 'User authenticated successfully' };
}



// app.use(bodyparser.json())
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.set('view engine', 'ejs');

app.post("/homepage", async (req, res) => {
    res.redirect("/homepage")
})

app.post("/game", async (req, res) => {
  res.redirect("/game")
})

app.post("/props", async (req,res) => {
    res.redirect("/props")
})

app.post("/playerstats", async (req,res) => {
  res.redirect("/playerstats")
})

app.post('/login', (req, res) => {
  const { email, password } = req.body;

  const user = users.find(user => user.username === email && bcrypt.compareSync(password, user.password));

  if (user) {
    req.session.user=user;

    res.redirect('/homepage)');
  } else {
  res.status(401).send('Invalid credentials');
  }
  const result = authenticateUser(email, password);
});

// Sign Up Function 
app.post("/register", async (req, res) => {
    try{
        const { email, password } = req.body;
        const userExists = users.some(user => user.email === email);
        const newUser = new User(email, password);


        if (err) {
          console.error(err);
          res.status(500).send('Error saving user to database');
          return;
        }

        if (userExists) {
          res.json({sucess: false, message: 'User already exists'});
        }
        const hashedPassword = bcrypt.hashSync(req.body.password,10)
        console.log(users);
        
        res.redirect("/login")
    } catch (e) {
        console.log(e);
        res.redirect("/register")
    }
})

// Routes

app.get('/login', (req, res) => {
    res.render('login')   
})

app.get('/register', (req, res) => {
    res.render('register')
})

app.get('/game', (req, res) => {
  res.render('game')
})

app.get('/homepage', (req, res) => {
    res.render('homepage')
})

app.get('/props', (req,res) => {
    res.render('props')
})

app.get('/playerstats', (req,res) => {
  res.render('playerstats')
})
// Routes End
//

connection.connect((error) => {
    if (error) {
    console.error('connection to the database was not successful', error);
    return;
}
console.log('connected to database');
});

class User {
  constructor(username, password) {
    this.username = username;
    this.password = password;
  }

  static findAll(callback) {
    const users = [
      { username: 'user1', password: 'password1' },
      { username: 'user2', password: 'password2' },
      { username: 'user3', password: 'password3' }
    ];
    callback(null, users);
  }

  static findByUsername(username, callback) {
    const user = [
      { username: 'user1', password: 'password1' },
      { username: 'user2', password: 'password2' },
      { username: 'user3', password: 'password3' }
    ].find(user => user.username === username);

    if (!user) {
      callback(null, null);
      return;
    }

    const foundUser = new User(user.username, user.password);
    callback(null, foundUser);
  }

  save(callback) {
    const users = [
      { username: 'user1', password: 'password1' },
      { username: 'user2', password: 'password2' },
      { username: 'user3', password: 'password3' }
    ];

    const existingUserIndex = users.findIndex(user => user.username === this.username);

    if (existingUserIndex >= 0) {
      users[existingUserIndex] = this;
      callback(null, this);
    } else {
      users.push(this);
      callback(null, this);
    }
  }

  delete(callback) {
    const users = [
      { username: 'user1', password: 'password1' },
      { username: 'user2', password: 'password2' },
      { username: 'user3', password: 'password3' }
    ];

    const userIndex = users.findIndex(user => user.username === this.username);

    if (userIndex >= 0) {
      users.splice(userIndex, 1);
      callback(null);
    } else {
      callback(null);
    }
  }
}

app.listen(3000, () => {
  console.log("on port 3000");
});
